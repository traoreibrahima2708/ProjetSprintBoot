export class ItemProduct{
  id:number;
  name:string;
  price:number;
  quantity:number;
}
